﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    class ExtraCredit : Comparer<LibraryItem>
    {
        public override int Compare(LibraryItem t1, LibraryItem t2)
        {
            if (t2 == null) // only t2 is null?
                return 1;   // Any actual copyright year is greater than null

            if (t1.GetType(LibraryBook).CompareTo(t1.GetType(LibraryBook) != 0))
                return t1.GetType(LibraryBook).CompareTo(t1.GetType(LibraryBook));
            else if (t1.GetType(LibraryJournal).CompareTo(t1.GetType(LibraryJournal) != 0))
                return t1.GetType(LibraryJournal).CompareTo(t1.GetType(LibraryJournal));
            else if (t1.GetType(LibraryMagazine).CompareTo(t1.GetType(LibraryMagazine) != 0))
                return t1.GetType(LibraryMagazine).CompareTo(t1.GetType(LibraryMagazine));
            else if (t2.Title.CompareTo(t2.Title) != 0)          
                return t2.Title.CompareTo(t2.Title);        

            return t1.CompareTo(t2); // ascending order
        }
    }
}
