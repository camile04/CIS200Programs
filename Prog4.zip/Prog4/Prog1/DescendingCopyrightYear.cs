﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LibraryItems
{
    class DescendingCopyrightYear : Comparer<LibraryItem>
    {
        public override int Compare(LibraryItem cry1, LibraryItem cry2)
        {
            // Ensure correct handling of null values (in .NET, null less than anything)
            if (cry1 == null && cry2 == null) // Both null?
                return 0;                 // Equal

            if (cry1 == null) // only cry1 is null?
                return -1;  // null is less than any actual copyright year

            if (cry2 == null) // only cry2 is null?
                return 1;   // Any actual copyright year is greater than null

            return cry2.CopyrightYear.CompareTo(cry1.CopyrightYear); // descending order
        }
    }
}
