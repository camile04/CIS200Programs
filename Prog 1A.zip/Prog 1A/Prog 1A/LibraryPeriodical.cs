﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_1A
{
	public abstract class LibraryPeriodical : LibraryItem
	{
		private int _volume; //periodical volume
		private int _number; //periodical number


		//initalize volume and number
		public LibraryPeriodical(int theVolume, int theNumber, string theTitle, string thePublisher,
			 int theCopyrightPeriod, int theLoanPeriod, string theCallNumber) : base(theTitle, thePublisher,
				 theCopyrightPeriod, theLoanPeriod, theCallNumber)

		{
			Volume = theVolume;
			Number = theNumber;

		}

		public int Volume
		{
			//precondition: none
			//postcondition: volume is returned
			get
			{
				return _volume;
			}
			//precondition: value is postitive
			//postcondition: volume value is set 
			set
			{
				if (_volume >= 1)
					value = _volume;
				else
					throw new ArgumentOutOfRangeException($"{nameof(Volume)}", value,
						$"{nameof(Volume)} value must be positive");
			}
		}
		public int Number
		{
			//precondition: none 
			//postcondition: number is set
			get
			{
				return _number;
			}
			//precondition: value is postitive 
			//postcondtion: number value is set
			set
			{
				if (_number >= 1)
					value = _number;
				else
					throw new ArgumentOutOfRangeException($"{nameof(Number)}", value,
						$"{nameof(Number)} value must be positive");
			}
		}

		public override string ToString()
		{
			string NL = Environment.NewLine;

			return $"Volume: {Volume}{NL} Number: {Number}";
		}
	}
}
