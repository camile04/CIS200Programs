﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_1A
{
	public class LibraryMagazine : LibraryPeriodical
	{
		decimal latefee;
		const decimal TOPPER = 20m;
		const decimal LATE = .25m;

		public LibraryMagazine(string theTitle, string thePublisher, int theCopyrightPeriod,
			int theLoanPeriod, string theCallNumber, int theVolume, int theNumber) :
			base(theVolume, theNumber, theTitle, thePublisher,
			 theCopyrightPeriod, theLoanPeriod, theCallNumber)
		{

		}
		public override decimal CalcLateFee(int calculation)
		{
			latefee = LATE * calculation;
			if (latefee <= TOPPER)
				return latefee;
			else
				return TOPPER;
		}
		public override string ToString()
		{
			return $"Magazine Late Fee: {latefee}";
		}
	}
}
