﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_1A
{
	public class LibraryMovie : LibraryMediaItem
	{
		private string _director; //director named
		public enum MPAARatings { G, PG, PG13, R, NC17, U };
		public MediaType _medium;
		private MPAARatings _rating;
		const decimal DVDLATE = 1.00M; //dvd and vhs late fee
		const decimal BLULATE = 1.50M; //bluray late fee
		const decimal LIMIT = 25m; //limit of late fee
		decimal lateFee;
		decimal lateBlu;


		public LibraryMovie(string theDirector, MediaType theMedium, MPAARatings theRating,
			string theTitle, string thePublisher, int theCopyrightPeriod,
			int theLoanPeriod, string theCallNumber, double theDuration) :
			base(theTitle, thePublisher, theCopyrightPeriod,
			theLoanPeriod, theCallNumber)
		{
			Director = theDirector;
			Medium = theMedium;
			Rating = theRating;
			IsCheckedOut();
		}

		public string Director
		{
			//precondition: none
			//postcondition: director is returned
			get
			{
				return _director;
			}
			//precondition: none
			//postcondition: director is set to a value
			set
			{
				if (string.IsNullOrWhiteSpace(value)) //includes test for null, all whitespace, and empty
					throw new ArgumentOutOfRangeException($"{nameof(Director)}", value,
						$"{nameof(Director)} must not be null or empty");
			}
		}
		public override MediaType Medium
		{
			//precondition: none
			//postcondition: medium is returned
			get
			{
				return _medium;
			}
			//precondition: value must be less than or equal to VHS
			//postcondition: medium value is set
			set
			{
				if (value <= MediaType.VHS)
					return;
				else
					throw new ArgumentOutOfRangeException($"{nameof(Medium)}", value,
						$"{nameof(Medium)} must be within range");
			}
		}
		public override MPAARatings Rating
		{
			//precondition: none
			//postcondition: rating is returned
			get
			{
				return _rating;
			}
			//precondition: none
			//postcondtion: rating value is set
			set
			{
				if (value >= MPAARatings.G)
					return;
			}
		}
		public override decimal CalcLateFee(int calculation)
		{
			lateFee = DVDLATE * calculation;
			lateBlu = BLULATE * calculation;
			if (Medium == MediaType.BLURAY && lateBlu <= LIMIT)
				return lateFee;
			else if (Medium == MediaType.DVD || Medium == MediaType.VHS && lateFee <= LIMIT)
				return lateBlu;
		}
		public override string ToString()
		{
			string NL = Environment.NewLine;
			return $"Director: {Director}{NL} Medium: {Medium}{NL} Rating: {Rating}";
		}
	}
}
