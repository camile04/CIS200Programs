﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_1A
{
	public class LibraryMusic : LibraryMediaItem
	{
		private string _artist;
		private int _numberOfTracks;
		public MediaType _medium;
		const decimal FEE = .50M;
		const decimal TOPPER = 20M;

		public LibraryMusic(string theArtist, int numberOfTracks, string theTitle, string thePublisher,
			int theCopyrightPeriod,int theLoanPeriod, string theCallNumber, double theDuration,
			MediaType theMedium) : base(theDuration, theTitle, thePublisher, theCopyrightPeriod,
			 theLoanPeriod, theCallNumber)

		{
			Artist = theArtist;
			NumberOfTracks = numberOfTracks;
			Medium = theMedium;
			IsCheckedOut();
		}

		public string Artist
		{
			//precondition: none
			//postcondition: artist value is returned
			get
			{
				return _artist;
			}
			//precondition: none
			//postcondition: artist value is set
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentOutOfRangeException($"{nameof(Artist)}", value,
						$"{nameof(Artist)} cannot be null or empty");
			}
		}

		public int NumberOfTracks
		{
			//precondition: none
			//postcondition: num of tracks is returned
			get
			{
				return _numberOfTracks;
			}
			//precondition: value must be postitive
			//postcondition: num of tracks value is set
			set
			{
				if (value >= 1)
					value = _numberOfTracks;
				else
					throw new ArgumentOutOfRangeException($"{nameof(NumberOfTracks)}", value,
						$"{nameof(NumberOfTracks)} must be positive");
			}
		}
		public override MediaType Medium
		{
			get
			{
				return _medium;
			}
			set
			{
				if (value >= MediaType.CD)
					return;
			}
		}
		public override decimal CalcLateFee(int calculation)
		{
			decimal latefee;
			latefee = FEE * calculation;
			if (latefee <= TOPPER)
				return latefee;
			else
				latefee = TOPPER;
			return latefee;
		}
	}
}
