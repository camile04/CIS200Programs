﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_1A
{
	public class LibraryBook : LibraryItem
	{
		const decimal LateFee = .25M;
		private string _author;

		public LibraryBook(string theAuthor, string theTitle, string thePublisher, int theCopyrightPeriod,
			   int theLoanPeriod, string theCallNumber) : base(theTitle, thePublisher, theCopyrightPeriod,
			   theLoanPeriod, theCallNumber)
		{
			Author = theAuthor;
			ReturnToShelf(); //makes sure book is not checked out
		}
		public string Author
		{
			//precondition: none
			//postcondition: author is returned
			get
			{
				return _author;
			}
			//precondition: none
			//postcondition: author has been set to a value
			set
			{
				//empty value is okay, change null to empty string
				_author = (value == null ? string.Empty : value.Trim());
			}
		}
		//precondition: cannot be negative
		//postcondition: returns calculated late fee
		public override decimal CalcLateFee(int calculation)
		{
			decimal latefee;
			latefee = LateFee * calculation;
			return latefee;
		}
		public override string ToString()
		{
			return $"Author: {Author}";
		}
	}
}