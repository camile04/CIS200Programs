﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_1A
{
	public class LibraryJournal : LibraryPeriodical
	{
		private string _discipline;
		private string _editor;
		const decimal FEE = .75m;

		public LibraryJournal(string theTitle, string thePublisher, string theDiscipline,
			string theEditor, string theCopyrightPeriod, int theLoanPeriod, string theCallNumber,
			int theVolume) : base(theVolume, theTitle, thePublisher, 
				theCopyrightPeriod, theLoanPeriod, theCallNumber)
		{
			Discipline = theDiscipline;
			Editor = theEditor;
		}
		public string Discipline
		{
			//precondition: none
			//postcondition: discipline is returned
			get
			{
				return _discipline;
			}
			//precondition: none
			//postcondition: discipline value is set
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentOutOfRangeException($"{nameof(Discipline)}", value,
						$"{nameof(Discipline)} must not be null or empty");
			}
		}
		public string Editor
		{
			//precondition: none
			//postcondition: editor is returned
			get
			{
				return _editor;
			}
			//precondition: none
			//postcondition: editor value is set
			set
			{
				if (string.IsNullOrWhiteSpace(value))
					throw new ArgumentOutOfRangeException($"{nameof(Editor)}", value,
						$"{nameof(Editor)} must not be null or empty");
			}
		}
		public override decimal CalcLateFee(int calculation)
		{
			decimal latefee;
			latefee = FEE * calculation;
			return latefee;
		}
		public override string ToString()
		{
			string NL = Environment.NewLine;
			return $"Discipline: {Discipline}{NL} Editor: {Editor}";

		}
	}
}
