﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_1A
{
	public abstract class LibraryMediaItem : LibraryItem
	{
		private double _duration; //defines duration of time library book is checked out
		public enum MediaType { DVD, BLURAY, VHS, CD, SACD, VINYL }; //defines types of media

		public abstract MediaType Medium //initialization of mediatype
		{
			get;
			set;
		}
		//precondition: duration must be none negative
		//postcondition: duration has been intialized
		public LibraryMediaItem(double theDuration, string theTitle, string thePublisher, int theCopyrightPeriod,
			 int theLoanPeriod, string theCallNumber) : base(theTitle, thePublisher, theCopyrightPeriod,
			 theLoanPeriod, theCallNumber)
		{
			Duration = theDuration;
			ReturnToShelf(); //isnt checked out
		}

		public double Duration
		{
			//precondition: none
			//post condition: duration is returned
			get
			{
				return _duration;
			}
			//precondition: value must be greater than zero
			//postcondition: duration value is set
			set
			{
				if (value >= 0)
					_duration = value;
				else
					throw new ArgumentOutOfRangeException($"{nameof(Duration)}", value,
						$"{nameof(Duration)} must be greater than zero");
			}
		}
		//precondition: none
		//postcondition: string is returned to rep duration of media checked out
		public override string ToString()
		{
			return $"Duration: {Duration}";
		}

	}
}