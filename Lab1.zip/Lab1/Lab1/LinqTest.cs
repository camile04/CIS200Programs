﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab1
{   // Z2820
	// Lab 1 
	// 2/7/18
	// CIS 200-01
	// To organize items in an array
    public class LinqTest
    {
        public static void Main(string[] args)
        {
            // initialize array of invoices
            Invoice[] invoices = { 
                new Invoice( 83, "Electric sander", 7, 57.98M ), 
                new Invoice( 24, "Power saw", 18, 99.99M ), 
                new Invoice( 7, "Sledge hammer", 11, 21.5M ), 
                new Invoice( 77, "Hammer", 76, 11.99M ), 
                new Invoice( 39, "Lawn mower", 3, 79.5M ), 
                new Invoice( 68, "Screwdriver", 106, 6.99M ), 
                new Invoice( 56, "Jig saw", 21, 11M ), 
                new Invoice( 3, "Wrench", 34, 7.5M ) };

            // Display original array
            Console.WriteLine("Original Invoice Data\n");
            Console.WriteLine("P.Num Part Description     Quant Price"); // Column Headers
            Console.WriteLine("----- -------------------- ----- ------");

			decimal minVal = 200.00M, maxVal = 500.00M;
			

			var PartDescript =
				from invoice in invoices
				orderby invoice.PartDescription
				select invoice;

			var Price =
				from invoice in invoices
				orderby invoice.Price
				select invoice;

			var PartDescQuantity =
				from invoice in invoices
				orderby invoice.Quantity
				select new { invoice.PartDescription, invoice.Quantity };

			var InvoiceTtl =
				from invoice in invoices
				let total = invoice.Quantity * invoice.Price
				orderby total
				select new { invoice.PartDescription, InvoiceTotal = total };

			var Between200500 =
				from invoice in InvoiceTtl
				where (invoice.InvoiceTotal >= minVal) && (invoice.InvoiceTotal <= maxVal)
				select invoice;


			foreach (Invoice inv in invoices)
                Console.WriteLine(inv);

			Console.WriteLine();

			foreach (var invoice in PartDescript)
				Console.WriteLine(invoice);

			Console.WriteLine();

			foreach (var invoice in Price)
				Console.WriteLine(invoice);

			Console.WriteLine();

			foreach (var invoice in PartDescQuantity)
				Console.WriteLine(invoice);

			Console.WriteLine();

			foreach (var invoice in InvoiceTtl)
				Console.WriteLine(invoice);

			Console.WriteLine();

			foreach (var invoice in Between200500)
				Console.WriteLine(invoice);
        }
    }
}
